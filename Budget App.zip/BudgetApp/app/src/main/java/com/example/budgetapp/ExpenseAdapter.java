package com.example.budgetapp;

public class ExpenseAdapter {
}
